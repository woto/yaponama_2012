!function(l, f) {
    function m() {
        var a = e.elements;
        return "string" == typeof a ? a.split(" ") :a;
    }
    function i(a) {
        var b = n[a[o]];
        return b || (b = {}, h++, a[o] = h, n[h] = b), b;
    }
    function p(a, b, c) {
        return b || (b = f), g ? b.createElement(a) :(c || (c = i(b)), b = c.cache[a] ? c.cache[a].cloneNode() :r.test(a) ? (c.cache[a] = c.createElem(a)).cloneNode() :c.createElem(a), 
        b.canHaveChildren && !s.test(a) ? c.frag.appendChild(b) :b);
    }
    function t(a, b) {
        b.cache || (b.cache = {}, b.createElem = a.createElement, b.createFrag = a.createDocumentFragment, 
        b.frag = b.createFrag()), a.createElement = function(c) {
            return e.shivMethods ? p(c, a, b) :b.createElem(c);
        }, a.createDocumentFragment = Function("h,f", "return function(){var n=f.cloneNode(),c=n.createElement;h.shivMethods&&(" + m().join().replace(/[\w\-]+/g, function(a) {
            return b.createElem(a), b.frag.createElement(a), 'c("' + a + '")';
        }) + ");return n}")(e, b.frag);
    }
    function q(a) {
        a || (a = f);
        var b = i(a);
        if (e.shivCSS && !j && !b.hasCSS) {
            var c, d = a;
            c = d.createElement("p"), d = d.getElementsByTagName("head")[0] || d.documentElement, 
            c.innerHTML = "x<style>article,aside,dialog,figcaption,figure,footer,header,hgroup,main,nav,section{display:block}mark{background:#FF0;color:#000}template{display:none}</style>", 
            c = d.insertBefore(c.lastChild, d.firstChild), b.hasCSS = !!c;
        }
        return g || t(a, b), a;
    }
    var j, g, k = l.html5 || {}, s = /^<|^(?:button|map|select|textarea|object|iframe|option|optgroup)$/i, r = /^(?:a|b|code|div|fieldset|h1|h2|h3|h4|h5|h6|i|label|li|ol|p|q|span|strong|style|table|tbody|td|th|tr|ul)$/i, o = "_html5shiv", h = 0, n = {};
    !function() {
        try {
            var a = f.createElement("a");
            a.innerHTML = "<xyz></xyz>", j = "hidden" in a;
            var b;
            if (!(b = 1 == a.childNodes.length)) {
                f.createElement("a");
                var c = f.createDocumentFragment();
                b = "undefined" == typeof c.cloneNode || "undefined" == typeof c.createDocumentFragment || "undefined" == typeof c.createElement;
            }
            g = b;
        } catch (d) {
            g = j = !0;
        }
    }();
    var e = {
        elements:k.elements || "abbr article aside audio bdi canvas data datalist details dialog figcaption figure footer header hgroup main mark meter nav output progress section summary template time video",
        version:"3.7.0",
        shivCSS:!1 !== k.shivCSS,
        supportsUnknownElements:g,
        shivMethods:!1 !== k.shivMethods,
        type:"default",
        shivDocument:q,
        createElement:p,
        createDocumentFragment:function(a, b) {
            if (a || (a = f), g) return a.createDocumentFragment();
            for (var b = b || i(a), c = b.frag.cloneNode(), d = 0, e = m(), h = e.length; h > d; d++) c.createElement(e[d]);
            return c;
        }
    };
    l.html5 = e, q(f);
}(this, document), /*! Respond.js v1.4.2: min/max-width media query polyfill
 * Copyright 2014 Scott Jehl
 * Licensed under MIT
 * http://j.mp/respondjs */
!function(a) {
    "use strict";
    a.matchMedia = a.matchMedia || function(a) {
        var b, c = a.documentElement, d = c.firstElementChild || c.firstChild, e = a.createElement("body"), f = a.createElement("div");
        return f.id = "mq-test-1", f.style.cssText = "position:absolute;top:-100em", e.style.background = "none", 
        e.appendChild(f), function(a) {
            return f.innerHTML = '&shy;<style media="' + a + '"> #mq-test-1 { width: 42px; }</style>', 
            c.insertBefore(e, d), b = 42 === f.offsetWidth, c.removeChild(e), {
                matches:b,
                media:a
            };
        };
    }(a.document);
}(this), function(a) {
    "use strict";
    function b() {
        v(!0);
    }
    var c = {};
    a.respond = c, c.update = function() {};
    var d = [], e = function() {
        var b = !1;
        try {
            b = new a.XMLHttpRequest();
        } catch (c) {
            b = new a.ActiveXObject("Microsoft.XMLHTTP");
        }
        return function() {
            return b;
        };
    }(), f = function(a, b) {
        var c = e();
        c && (c.open("GET", a, !0), c.onreadystatechange = function() {
            4 !== c.readyState || 200 !== c.status && 304 !== c.status || b(c.responseText);
        }, 4 !== c.readyState && c.send(null));
    }, g = function(a) {
        return a.replace(c.regex.minmaxwh, "").match(c.regex.other);
    };
    if (c.ajax = f, c.queue = d, c.unsupportedmq = g, c.regex = {
        media:/@media[^\{]+\{([^\{\}]*\{[^\}\{]*\})+/gi,
        keyframes:/@(?:\-(?:o|moz|webkit)\-)?keyframes[^\{]+\{(?:[^\{\}]*\{[^\}\{]*\})+[^\}]*\}/gi,
        comments:/\/\*[^*]*\*+([^/][^*]*\*+)*\//gi,
        urls:/(url\()['"]?([^\/\)'"][^:\)'"]+)['"]?(\))/g,
        findStyles:/@media *([^\{]+)\{([\S\s]+?)$/,
        only:/(only\s+)?([a-zA-Z]+)\s?/,
        minw:/\(\s*min\-width\s*:\s*(\s*[0-9\.]+)(px|em)\s*\)/,
        maxw:/\(\s*max\-width\s*:\s*(\s*[0-9\.]+)(px|em)\s*\)/,
        minmaxwh:/\(\s*m(in|ax)\-(height|width)\s*:\s*(\s*[0-9\.]+)(px|em)\s*\)/gi,
        other:/\([^\)]*\)/g
    }, c.mediaQueriesSupported = a.matchMedia && null !== a.matchMedia("only all") && a.matchMedia("only all").matches, 
    !c.mediaQueriesSupported) {
        var h, i, j, k = a.document, l = k.documentElement, m = [], n = [], o = [], p = {}, q = 30, r = k.getElementsByTagName("head")[0] || l, s = k.getElementsByTagName("base")[0], t = r.getElementsByTagName("link"), u = function() {
            var a, b = k.createElement("div"), c = k.body, d = l.style.fontSize, e = c && c.style.fontSize, f = !1;
            return b.style.cssText = "position:absolute;font-size:1em;width:1em", c || (c = f = k.createElement("body"), 
            c.style.background = "none"), l.style.fontSize = "100%", c.style.fontSize = "100%", 
            c.appendChild(b), f && l.insertBefore(c, l.firstChild), a = b.offsetWidth, f ? l.removeChild(c) :c.removeChild(b), 
            l.style.fontSize = d, e && (c.style.fontSize = e), a = j = parseFloat(a);
        }, v = function(b) {
            var c = "clientWidth", d = l[c], e = "CSS1Compat" === k.compatMode && d || k.body[c] || d, f = {}, g = t[t.length - 1], p = new Date().getTime();
            if (b && h && q > p - h) return a.clearTimeout(i), void (i = a.setTimeout(v, q));
            h = p;
            for (var s in m) if (m.hasOwnProperty(s)) {
                var w = m[s], x = w.minw, y = w.maxw, z = null === x, A = null === y, B = "em";
                x && (x = parseFloat(x) * (x.indexOf(B) > -1 ? j || u() :1)), y && (y = parseFloat(y) * (y.indexOf(B) > -1 ? j || u() :1)), 
                w.hasquery && (z && A || !(z || e >= x) || !(A || y >= e)) || (f[w.media] || (f[w.media] = []), 
                f[w.media].push(n[w.rules]));
            }
            for (var C in o) o.hasOwnProperty(C) && o[C] && o[C].parentNode === r && r.removeChild(o[C]);
            o.length = 0;
            for (var D in f) if (f.hasOwnProperty(D)) {
                var E = k.createElement("style"), F = f[D].join("\n");
                E.type = "text/css", E.media = D, r.insertBefore(E, g.nextSibling), E.styleSheet ? E.styleSheet.cssText = F :E.appendChild(k.createTextNode(F)), 
                o.push(E);
            }
        }, w = function(a, b, d) {
            var e = a.replace(c.regex.comments, "").replace(c.regex.keyframes, "").match(c.regex.media), f = e && e.length || 0;
            b = b.substring(0, b.lastIndexOf("/"));
            var h = function(a) {
                return a.replace(c.regex.urls, "$1" + b + "$2$3");
            }, i = !f && d;
            b.length && (b += "/"), i && (f = 1);
            for (var j = 0; f > j; j++) {
                var k, l, o, p;
                i ? (k = d, n.push(h(a))) :(k = e[j].match(c.regex.findStyles) && RegExp.$1, n.push(RegExp.$2 && h(RegExp.$2))), 
                o = k.split(","), p = o.length;
                for (var q = 0; p > q; q++) l = o[q], g(l) || m.push({
                    media:l.split("(")[0].match(c.regex.only) && RegExp.$2 || "all",
                    rules:n.length - 1,
                    hasquery:l.indexOf("(") > -1,
                    minw:l.match(c.regex.minw) && parseFloat(RegExp.$1) + (RegExp.$2 || ""),
                    maxw:l.match(c.regex.maxw) && parseFloat(RegExp.$1) + (RegExp.$2 || "")
                });
            }
            v();
        }, x = function() {
            if (d.length) {
                var b = d.shift();
                f(b.href, function(c) {
                    w(c, b.href, b.media), p[b.href] = !0, a.setTimeout(function() {
                        x();
                    }, 0);
                });
            }
        }, y = function() {
            for (var b = 0; b < t.length; b++) {
                var c = t[b], e = c.href, f = c.media, g = c.rel && "stylesheet" === c.rel.toLowerCase();
                e && g && !p[e] && (c.styleSheet && c.styleSheet.rawCssText ? (w(c.styleSheet.rawCssText, e, f), 
                p[e] = !0) :(!/^([a-zA-Z:]*\/\/)/.test(e) && !s || e.replace(RegExp.$1, "").split("/")[0] === a.location.host) && ("//" === e.substring(0, 2) && (e = a.location.protocol + e), 
                d.push({
                    href:e,
                    media:f
                })));
            }
            x();
        };
        y(), c.update = y, c.getEmValue = u, a.addEventListener ? a.addEventListener("resize", b, !1) :a.attachEvent && a.attachEvent("onresize", b);
    }
}(this);